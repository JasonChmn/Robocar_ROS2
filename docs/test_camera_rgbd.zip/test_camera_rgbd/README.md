# Test caméra RGBD (OAK-D-Lite)

```bash
docker build -t test_camera_rgbd .
```


## Test 1 : caméra sur le PC

```bash
./run.sh python3 test1_python.py
```

## Test 2 : caméra sur la Jetson, RViz sur le PC

```bash
export ROS_DOMAIN_ID=<votre numéro>   # le même que dans ~/Robocar_ROS2/.env et sur le PC
./run.sh ./test2.sh
```

Sur le PC

```bash
sudo apt install ros-jazzy-image-transport-plugins
rviz2 -d camera.rviz
```

## Test 3 : IMU sur le PC

Caméra branchée sur le PC.

```bash
./run.sh python3 test3_imu.py
```


## Réglages caméra : `camera_params.yaml`

Les paramètres utiles du driver ROS2 (les autres gardent leur valeur par défaut), au format du driver. Les tests le chargent :
- test 2 : le driver le lit directement (`params_file`) ;
- tests 1 et 3 : `camera.py` applique les paramètres de la partie « test 1 + ROS » de chaque section.

Valeurs par défaut du driver, sauf celles marquées `modified` : USB 2 forcé, 15 FPS, RGB en 480x270,
focus fixé sur la valeur de calibration usine (`$(env LENS)`), profondeur alignée sur la RGB.

## Performances avec USB 2 et USB 3

Alimentation et débit selon le port :
- **USB 2** : 0,5 A × 5 V = 2,5 W, ~480 Mbit/s. RGB-D OK mais bridée (FPS réduits).
- **USB 3** : 0,9 A × 5 V = 4,5 W, 5 Gbit/s. Il faut un port USB 3 (bleu) et un câble USB 3.
  Nécessaire pour la pleine charge (~5 W avec réseau de neurones sur la caméra).

Sans câble USB 3, la caméra reste en USB 2 (`USB: HIGH` dans le diagnostic). À 30 FPS, ça ne suffit pas :
elle décroche au démarrage (`Device already closed or disconnected: Input/output error`).

Pour l'instant (si pas de câble USB 3) : USB 2 forcé (`camera.i_usb_speed: HIGH`) et `i_fps: 15.0` (10 marche aussi) dans `camera_params.yaml`.

## Adapter à son environnement

Dans `camera_params.yaml`. Les valeurs `r_*` ne s'appliquent que si leur interrupteur `r_set_*` est à `true`.

| Problème | Paramètres |
|---|---|
| Image qui scintille, bandes (néons) | `rgb` / `left` / `right` : `r_set_man_exposure: true`, `r_exposure` multiple de 10000 µs (secteur 50 Hz), luminosité avec `r_iso` |
| Couleurs fausses ou qui dérivent | `rgb` : `r_set_man_whitebalance: true`, `r_whitebalance` (3000 K chaud … 6500 K froid) |
| Image RGB floue | `rgb` : `r_focus` (0-255). `r_set_man_focus: false` = autofocus, mais l'alignement RGB / profondeur se décale |
| Profondeur trouée | `stereo` : `i_depth_preset: HIGH_DENSITY`, `i_enable_spatial_filter: true` |
| Profondeur bruitée, taches | `stereo` : baisser `i_stereo_conf_threshold`, `i_enable_speckle_filter: true`, `i_enable_temporal_filter: true` (scène fixe) |
| Points aberrants trop près / trop loin | `stereo` : `i_enable_threshold_filter: true`, `i_threshold_filter_min_range` / `max_range` (mm) |
| Objets très proches absents | `stereo` : `i_extended_disp: true` |
| Caméra qui décroche | baisser `i_fps` (rgb, left, right) |
