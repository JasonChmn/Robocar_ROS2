"""Test 1: depthai only, without ROS2. Shows RGB | depth side by side. Press 'q' to quit.

Camera settings: camera_params.yaml (same as test 2).
"""
import cv2
import numpy as np

import camera

params = camera.load_params()
with camera.open_device(params) as device:
    device.startPipeline(camera.build_pipeline(device, params))
    q_rgb = device.getOutputQueue("rgb", maxSize=4, blocking=False)
    q_depth = device.getOutputQueue("depth", maxSize=4, blocking=False)
    first = True
    while cv2.waitKey(1) != ord("q"):
        color = q_rgb.get().getCvFrame()
        raw = q_depth.get().getFrame()  # uint16 in mm, 0 = no measurement
        if first:
            print(camera.describe_frames(color, raw))
            first = False
        depth = cv2.resize(camera.colorize_depth(raw), (color.shape[1], color.shape[0]))
        cv2.imshow("RGB | Depth", np.hstack((color, depth)))
