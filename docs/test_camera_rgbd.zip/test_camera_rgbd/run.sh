#!/bin/bash
# Run a command in the container (USB camera + display), after the camera diagnostic.
# The IMU test skips the diagnostic: it only checks the RGB-D stream and adds ~7 s to startup.
# Host network: ROS2 topics reach the PC (test 2). Host IPC: Fast DDS shared memory with the other
# containers of the Jetson (Robocar_ROS2 uses ipc: host too).
CHECK='python3 check_camera.py &&'
[[ "$*" == *test3_imu* ]] && CHECK=''
xhost +local:root >/dev/null 2>&1  # fails harmlessly without a display (Jetson over SSH)
docker run --rm -it --privileged --network host --ipc host \
  -v /dev/bus/usb:/dev/bus/usb \
  -e DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
  -e ROS_DOMAIN_ID -e ROS_AUTOMATIC_DISCOVERY_RANGE=SUBNET \
  -v "$(dirname "$(realpath "$0")")":/ws -w /ws \
  test_camera_rgbd bash -c "$CHECK"' exec "$@"' _ "$@"
