"""Camera diagnostic: detection, USB speed, then sensors running for 1 s.

Power draw cannot be measured directly, so a lack of current is detected by its effects
(USB 2 = 500 mA max, camera disconnecting once the sensors are running).
Camera settings: camera_params.yaml (same as the tests).
"""
import sys
import time

import depthai as dai

import camera

DURATION = 1  # s


def fail(msg):
    sys.exit(f"ERROR: {msg}")


if not dai.Device.getAllAvailableDevices():
    fail("no camera detected (check the cable: lsusb | grep 03e7)")

params = camera.load_params()
print("Connecting to the camera...")
start = time.time()
try:
    with camera.open_device(params) as device:
        print("Camera:", device.getDeviceName(), device.getMxId())
        if device.hasCrashDump():
            print("WARNING: the camera crashed during a previous session", file=sys.stderr)
        device.startPipeline(camera.build_pipeline(device, params))

        q = device.getOutputQueue("depth", maxSize=4, blocking=False)
        q.get()  # first frame: the camera has started
        t0, frames = time.time(), 0
        while time.time() - t0 < DURATION:
            q.get()
            frames += 1
            if frames % 15 == 0:
                t = device.getChipTemperature().average
                print(f"  {time.time() - t0:4.1f} s  {frames} frames  {t:.0f} °C")
except RuntimeError as e:
    fail(f"the camera disconnected after {time.time() - start:.1f} s ({e})\n"
         "-> typical of insufficient power or a bad cable")

print(f"OK: {frames / DURATION:.0f} frames/s for {DURATION} s without disconnecting")
