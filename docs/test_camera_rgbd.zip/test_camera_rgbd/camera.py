"""Open the camera and build the depthai pipeline from camera_params.yaml.

The YAML uses the ROS2 driver format so that test 1 and the ROS driver share the same settings.
Mirrors the depthai_ros_driver 2.12 code (param_handlers/sensor and stereo).
"""
import os
import re

import cv2
import depthai as dai
import yaml

PARAMS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "camera_params.yaml")
FILTERS = dai.RawStereoDepthConfig.PostProcessing
MAX_DEPTH = 5000  # mm, top of the depth color scale


def load_params():
    with open(PARAMS_FILE) as f:
        return yaml.safe_load(f)["/**"]["ros__parameters"]


def open_device(params):
    speed = dai.UsbSpeed.__members__[params["camera"]["i_usb_speed"]]
    return dai.Device(dai.OpenVINO.DEFAULT_VERSION, speed)


def _resolution(enum, name):
    # "1080P" -> THE_1080_P, "4K" -> THE_4_K, "1440X1080" -> THE_1440X1080
    return enum.__members__["THE_" + re.sub(r"^(\d+)([A-Z]+)$", r"\1_\2", name)]


def _sensor(cam, p, socket):
    """Apply the settings shared by the RGB and mono sensors."""
    ctrl = cam.initialControl
    cam.setBoardSocket(socket)
    cam.setFps(p["i_fps"])
    if p["r_set_man_exposure"]:
        ctrl.setManualExposure(p["r_exposure"], p["r_iso"])
    if p["r_set_auto_exposure_limit"]:
        ctrl.setAutoExposureLimit(p["r_auto_exposure_limit"])
    if p["r_set_sharpness"]:
        ctrl.setSharpness(p["r_sharpness"])
    if p["r_set_luma_denoise"]:
        ctrl.setLumaDenoise(p["r_luma_denoise"])
    if p["r_set_chroma_denoise"]:
        ctrl.setChromaDenoise(p["r_chroma_denoise"])


def _rgb(pipeline, p, lens):
    rgb = pipeline.create(dai.node.ColorCamera)
    _sensor(rgb, p, dai.CameraBoardSocket.CAM_A)
    rgb.setResolution(_resolution(dai.ColorCameraProperties.SensorResolution, p["i_resolution"]))
    if p["i_set_isp_scale"]:
        rgb.setIspScale(p["i_isp_num"], p["i_isp_den"])
    if p["r_set_man_focus"]:
        # "$(env LENS)" in the YAML -> lens position read from the factory calibration
        rgb.initialControl.setManualFocus(lens if isinstance(p["r_focus"], str) else p["r_focus"])
    if p["r_set_man_whitebalance"]:
        rgb.initialControl.setManualWhiteBalance(p["r_whitebalance"])
    return rgb


def _mono(pipeline, p, socket):
    mono = pipeline.create(dai.node.MonoCamera)
    _sensor(mono, p, socket)
    mono.setResolution(_resolution(dai.MonoCameraProperties.SensorResolution, p["i_resolution"]))
    return mono


def _stereo(pipeline, p):
    stereo = pipeline.create(dai.node.StereoDepth)
    stereo.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.__members__[p["i_depth_preset"]])
    stereo.setLeftRightCheck(p["i_lr_check"])
    if p["i_align_depth"]:
        stereo.setDepthAlign(dai.CameraBoardSocket.CAM_A)
    stereo.setOutputSize(p["i_width"], p["i_height"])
    stereo.setExtendedDisparity(p["i_extended_disp"])

    init = stereo.initialConfig
    init.setLeftRightCheckThreshold(10)  # forced by the ROS driver (the preset uses 5)
    init.setMedianFilter(dai.MedianFilter(p["i_depth_filter_size"]))
    init.setConfidenceThreshold(p["i_stereo_conf_threshold"])
    init.setSubpixel(p["i_subpixel"])

    config = init.get()
    config.costMatching.disparityWidth = \
        dai.RawStereoDepthConfig.CostMatching.DisparityWidth.__members__[p["i_disparity_width"]]
    post = config.postProcessing
    if p["i_enable_temporal_filter"]:
        post.temporalFilter.enable = True
        post.temporalFilter.alpha = p["i_temporal_filter_alpha"]
        post.temporalFilter.delta = p["i_temporal_filter_delta"]
        post.temporalFilter.persistencyMode = \
            FILTERS.TemporalFilter.PersistencyMode.__members__[p["i_temporal_filter_persistency"]]
    if p["i_enable_spatial_filter"]:
        post.spatialFilter.enable = True
        post.spatialFilter.holeFillingRadius = p["i_spatial_filter_hole_filling_radius"]
        post.spatialFilter.alpha = p["i_spatial_filter_alpha"]
        post.spatialFilter.delta = p["i_spatial_filter_delta"]
        post.spatialFilter.numIterations = p["i_spatial_filter_iterations"]
    if p["i_enable_speckle_filter"]:
        post.speckleFilter.enable = True
        post.speckleFilter.speckleRange = p["i_speckle_filter_speckle_range"]
    if p["i_enable_threshold_filter"]:
        post.thresholdFilter.minRange = p["i_threshold_filter_min_range"]
        post.thresholdFilter.maxRange = p["i_threshold_filter_max_range"]
    if p["i_enable_brightness_filter"]:
        post.brightnessFilter.minBrightness = p["i_brightness_filter_min_brightness"]
        post.brightnessFilter.maxBrightness = p["i_brightness_filter_max_brightness"]
    init.set(config)
    return stereo


def build_pipeline(device, params):
    """Build the RGB + depth pipeline, with "rgb" and "depth" outputs."""
    lens = device.readCalibration().getLensPosition(dai.CameraBoardSocket.CAM_A)
    pipeline = dai.Pipeline()
    rgb = _rgb(pipeline, params["rgb"], lens)
    left = _mono(pipeline, params["left"], dai.CameraBoardSocket.CAM_B)
    right = _mono(pipeline, params["right"], dai.CameraBoardSocket.CAM_C)
    stereo = _stereo(pipeline, params["stereo"])
    left.out.link(stereo.left)
    right.out.link(stereo.right)
    for name, output in (("rgb", rgb.isp), ("depth", stereo.depth)):
        xout = pipeline.create(dai.node.XLinkOut)
        xout.setStreamName(name)
        output.link(xout.input)
    print(f"Lens position: {lens} | USB: {device.getUsbSpeed().name}")
    print(describe(params))
    return pipeline


def describe(params):
    rgb, mono, st = params["rgb"], params["left"], params["stereo"]
    filters = [f for f in ("temporal", "spatial", "speckle", "threshold", "brightness")
               if st[f"i_enable_{f}_filter"]]
    return (f"FPS: {rgb['i_fps']:g}\n"
            f"RGB: sensor {rgb['i_resolution']} -> {rgb['i_width']}x{rgb['i_height']}"
            f" | focus {'fixed' if rgb['r_set_man_focus'] else 'auto'}\n"
            f"Mono: {mono['i_resolution']}\n"
            f"Depth: {st['i_width']}x{st['i_height']} | {st['i_depth_preset']}"
            f" | confidence {st['i_stereo_conf_threshold']} | subpixel {st['i_subpixel']}"
            f" | extended {st['i_extended_disp']} | filters: {', '.join(filters) or 'none'}")


def describe_frames(color, depth):
    return (f"Frames received: RGB {color.shape[1]}x{color.shape[0]} = {color.nbytes // 1000} KB"
            f" | depth {depth.shape[1]}x{depth.shape[0]} = {depth.nbytes // 1000} KB")


def colorize_depth(raw):
    """uint16 depth in mm -> BGR image: 0-5 m in false colors, pixels without a measurement in black."""
    depth = cv2.applyColorMap(cv2.convertScaleAbs(raw, alpha=255 / MAX_DEPTH), cv2.COLORMAP_JET)
    depth[raw == 0] = 0
    return depth
