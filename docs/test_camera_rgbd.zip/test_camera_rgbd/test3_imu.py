"""Test 3: live IMU plots. Close the window to quit.

Raw measurements are thin lines, the EMA smoothing thick lines. Settings: imu section of camera_params.yaml.
At rest, the accelerometer measures gravity (~9.81 m/s²), split across the axes according to the tilt.
Orientation: complementary filter (gyro + gravity). Assumes the camera stands upright (IMU y axis vertical).
Yaw (rotation around the vertical) only relies on the gyro, so it drifts slowly (no magnetometer).
Velocity = integral of the acceleration without gravity, position = integral of the velocity.
Both drift mainly because of biases (small constant offsets), which smoothing does not remove.
Correction: when the camera is detected still, velocity is reset to 0 (ZUPT) and position stops drifting.
Press 'r' to reset velocity and position to 0.
"""
import math
import time
from collections import deque

import depthai as dai
import matplotlib.pyplot as plt
import numpy as np

import camera

WINDOW = 5         # s displayed
EMA_ALPHA = 0.05   # smoothing: smaller = smoother (0.05 at ~250 Hz ≈ 80 ms time constant)
CALIB = 1          # s held still at startup to measure the gyro bias
GRAVITY_GAIN = 0.002  # accelerometer weight in the gravity estimate (0.002 at ~250 Hz ≈ 2 s)
STILL_ACC = 0.08   # m/s²: below this (smoothed acceleration without gravity), considered still
STILL_GYRO = 1.0   # °/s: same for rotation
STILL_TIME = 0.2   # s still before resetting velocity to 0

# key: (title, unit, names of the 3 curves, position in the 12x2 grid)
# Left column: translation; right column: rotation
PLOTS = {
    "acc": ("Accelerometer (including gravity)", "m/s²", "xyz", (slice(0, 3), 0)),
    "lin": ("Acceleration without gravity", "m/s²", "xyz", (slice(3, 6), 0)),
    "vel": ("Velocity ('r' = reset)", "m/s", "xyz", (slice(6, 9), 0)),
    "pos": ("Position ('r' = reset)", "m", "xyz", (slice(9, 12), 0)),
    "gyro": ("Gyroscope", "°/s", "xyz", (slice(0, 6), 1)),
    "angle": ("Orientation", "°", ("roll", "pitch", "yaw"), (slice(6, 12), 1)),
}
COLORS = ("tab:red", "tab:green", "tab:blue")

fig = plt.figure(figsize=(15, 11))
grid = fig.add_gridspec(12, 2)
axes = []
for k, (*_, pos) in PLOTS.items():
    axes.append(fig.add_subplot(grid[pos], sharex=axes[0] if axes else None))
t = deque()
data = {(k, kind, i): deque() for k in PLOTS for kind in ("raw", "ema") for i in range(3)}
lines = {}
for ax, (k, (_, unit, names, _)) in zip(axes, PLOTS.items()):
    for i, (name, color) in enumerate(zip(names, COLORS)):
        lines[k, "raw", i], = ax.plot([], [], color=color, lw=0.7, alpha=0.35)
        lines[k, "ema", i], = ax.plot([], [], color=color, lw=2, label=name)
    ax.set_ylabel(unit)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper left", fontsize=8)
    ax.tick_params(labelbottom=k in ("pos", "angle"))
for k in ("pos", "angle"):
    axes[list(PLOTS).index(k)].set_xlabel("time (s)")
fig.tight_layout(rect=(0, 0, 1, 0.93), h_pad=2.5)

velocity, position = np.zeros(3), np.zeros(3)
fig.canvas.mpl_connect("key_press_event", lambda e: (velocity.fill(0), position.fill(0)) if e.key == "r" else None)

# Show the window right away, connecting to the camera takes a few seconds
fig.suptitle("Connecting to the camera...")
plt.pause(0.1)

params = camera.load_params()
p = params["imu"]
with camera.open_device(params) as device:
    print("IMU:", device.getConnectedIMU())
    pipeline = dai.Pipeline()
    imu = pipeline.create(dai.node.IMU)
    imu.enableIMUSensor(dai.IMUSensor.__members__[p["i_acc_mode"]], p["i_acc_freq"])
    imu.enableIMUSensor(dai.IMUSensor.__members__[p["i_gyro_mode"]], p["i_gyro_freq"])
    xout = pipeline.create(dai.node.XLinkOut)
    xout.setStreamName("imu")
    imu.out.link(xout.input)
    device.startPipeline(pipeline)
    q = device.getOutputQueue("imu", maxSize=50, blocking=False)

    # Calibration: 1 s still -> gyro bias (otherwise yaw and velocity drift) and initial gravity
    fig.suptitle(f"Calibration {CALIB} s: keep the camera still...")
    samples, t_end = [], None
    while t_end is None or time.time() < t_end:
        plt.pause(0.05)
        for pk in (pk for msg in q.tryGetAll() for pk in msg.packets):
            samples.append([pk.acceleroMeter.x, pk.acceleroMeter.y, pk.acceleroMeter.z,
                            pk.gyroscope.x, pk.gyroscope.y, pk.gyroscope.z])
        if samples and t_end is None:  # timer starts at the first measurement received
            t_end = time.time() + CALIB
    samples = np.mean(samples, axis=0)
    gravity, gyro_bias = samples[:3], samples[3:]
    print(f"Gyro bias (°/s): {np.degrees(gyro_bias).round(3)}")
    q.tryGetAll()  # drop packets received during calibration

    t0, n, t_dev, t_prev = time.time(), 0, None, None
    yaw, still_acc, still_gyro, still_since = 0.0, 0.0, 0.0, None
    ema = {}
    while plt.fignum_exists(fig.number):
        for msg in q.tryGetAll():
            for pk in msg.packets:
                n += 1
                # Camera timestamp (packets reach the host in batches)
                ts = pk.acceleroMeter.getTimestampDevice().total_seconds()
                t_dev = ts if t_dev is None else t_dev
                dt = 0.0 if t_prev is None else ts - t_prev
                t_prev = ts
                a = np.array([pk.acceleroMeter.x, pk.acceleroMeter.y, pk.acceleroMeter.z])
                w = np.array([pk.gyroscope.x, pk.gyroscope.y, pk.gyroscope.z]) - gyro_bias  # rad/s

                # Gravity as seen by the IMU: rotated by the gyro, slowly pulled toward the accelerometer
                gravity = gravity - np.cross(w, gravity) * dt
                gravity += GRAVITY_GAIN * (a - gravity)
                up = gravity / np.linalg.norm(gravity)
                yaw += math.degrees(np.dot(w, up) * dt)
                roll = math.degrees(math.atan2(up[0], up[1]))
                pitch = math.degrees(math.atan2(-up[2], up[1]))

                lin = a - gravity
                still_acc += EMA_ALPHA * (np.linalg.norm(lin) - still_acc)
                still_gyro += EMA_ALPHA * (math.degrees(np.linalg.norm(w)) - still_gyro)
                if still_acc < STILL_ACC and still_gyro < STILL_GYRO:
                    still_since = ts if still_since is None else still_since
                else:
                    still_since = None
                still = still_since is not None and ts - still_since > STILL_TIME

                t.append(ts - t_dev)
                velocity[:] = 0 if still else velocity + lin * dt
                position += velocity * dt
                values = {"acc": a, "lin": lin, "vel": velocity, "pos": position,
                          "gyro": np.degrees(w), "angle": (roll, pitch, yaw)}
                for k, v in values.items():
                    for i in range(3):
                        ema[k, i] = v[i] if (k, i) not in ema else ema[k, i] + EMA_ALPHA * (v[i] - ema[k, i])
                        data[k, "raw", i].append(v[i])
                        data[k, "ema", i].append(ema[k, i])
        while t and t[-1] - t[0] > WINDOW:
            t.popleft()
            for d in data.values():
                d.popleft()
        if t:
            for key, line in lines.items():
                line.set_data(t, data[key])
            for ax, (k, (title, unit, names, _)) in zip(axes, PLOTS.items()):
                ax.relim()
                ax.autoscale_view()
                vals = "  ".join(f"{name} {ema[k, i]:6.2f}" for i, name in enumerate(names))
                if k == "acc":
                    vals += f"   |norm| {math.sqrt(sum(ema[k, i] ** 2 for i in range(3))):5.2f}"
                ax.set_title(f"{title} ({unit}):  {vals}", fontsize=10)
            axes[0].set_xlim(t[0], max(t[-1], t[0] + WINDOW))
            state = "STILL (velocity reset to 0)" if still else "moving"
            fig.suptitle(f"IMU {n / (time.time() - t0):.0f} Hz — thin: measurement, thick: EMA (alpha {EMA_ALPHA})\n"
                         f"{state} — accel. {still_acc:.3f} m/s² (threshold {STILL_ACC}), "
                         f"rotation {still_gyro:.2f} °/s (threshold {STILL_GYRO})")
        plt.pause(0.05)
