"""Test 2 (on the Jetson): republish the depth as a colored JPEG, light enough to watch in RViz over Wi-Fi.

The real depth (/oak/stereo/image_raw, uint16 in mm) only compresses losslessly (PNG, ~75 KB per frame).
This preview is ~15 KB, for display only: its colors do not give exact distances.
"""
import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage, Image

import camera

JPEG_QUALITY = 50

rclpy.init()
node = Node("depth_viz")
bridge = CvBridge()
pub = node.create_publisher(CompressedImage, "/oak/stereo/depth_viz/compressed", qos_profile_sensor_data)


def publish(msg):
    if pub.get_subscription_count() == 0:
        return  # nobody watching: skip the encoding
    depth = camera.colorize_depth(bridge.imgmsg_to_cv2(msg))
    # Format string expected by the compressed image_transport decoder (RViz)
    out = CompressedImage(header=msg.header, format="bgr8; jpeg compressed bgr8")
    out.data = cv2.imencode(".jpg", depth, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])[1].tobytes()
    pub.publish(out)


node.create_subscription(Image, "/oak/stereo/image_raw", publish, qos_profile_sensor_data)
rclpy.spin(node)
