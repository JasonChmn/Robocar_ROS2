#!/bin/bash
# Test 2 (on the Jetson): ROS2 driver with camera_params.yaml (same settings as test 1).
# Viewed from the PC with RViz: rviz2 -d camera.rviz
# LENS: lens position read from the factory calibration, substituted into the YAML.
[[ -n "$ROS_DOMAIN_ID" ]] || { echo "ERROR: ROS_DOMAIN_ID is not set (export it, same value as on the PC)" >&2; exit 1; }
export LENS=$(python3 -c "
import camera, depthai as dai
with camera.open_device(camera.load_params()) as d:
    print(d.readCalibration().getLensPosition(dai.CameraBoardSocket.CAM_A))" 2>/dev/null | tail -1)
[[ "$LENS" =~ ^[0-9]+$ ]] || { echo "ERROR: cannot read the calibration (camera disconnected?)" >&2; exit 1; }
echo "Lens position: $LENS | ROS_DOMAIN_ID: $ROS_DOMAIN_ID"
python3 depth_viz.py &  # stops with the container when the driver exits
exec ros2 launch depthai_ros_driver camera.launch.py params_file:=/ws/camera_params.yaml
